"""Package only application source/assets, never chats, models or local QA data."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil

root = Path(__file__).resolve().parent.parent
allowed_dirs = ("src", "public", "scripts", "tests")
allowed_files = ("README.md", "LICENSE", "VERIFIKATION.md", "package.json", "pnpm-lock.yaml", "pnpm-workspace.yaml", "tsconfig.json", "vite.config.ts", "index.html")
source = root / "dist" / "Mega-Quellcode.zip"
with ZipFile(source, "w", ZIP_DEFLATED) as archive:
    for name in allowed_files:
        file = root / name
        if file.exists():
            archive.write(file, "Mega-iPhone/" + name)
    for name in allowed_dirs:
        for file in sorted((root / name).rglob("*")):
            if file.is_file() and "__pycache__" not in file.parts:
                archive.write(file, "Mega-iPhone/" + file.relative_to(root).as_posix())
for name in ("README.md", "LICENSE", "VERIFIKATION.md"):
    if (root / name).exists():
        shutil.copyfile(root / name, root / "dist" / name)
with ZipFile(root.parent / "Mega-iPhone.zip", "w", ZIP_DEFLATED) as archive:
    for file in sorted((root / "dist").rglob("*")):
        if file.is_file():
            archive.write(file, "Mega-iPhone/" + file.relative_to(root / "dist").as_posix())
print("App-Paket und vollständiger Quellcode erstellt.")
