import fs from 'node:fs';import path from 'node:path';import {createRequire} from 'node:module';
import {gzipSync} from 'node:zlib';
const root=path.resolve(import.meta.dirname,'..'),dist=path.join(root,'dist'),req=createRequire(fs.realpathSync(path.join(root,'node_modules/@huggingface/transformers/package.json')));
const onnx=path.resolve(path.dirname(req.resolve('onnxruntime-web')),'..');
fs.mkdirSync(path.join(dist,'runtime'),{recursive:true});
const runtime='ort-wasm-simd-threaded.jsep';
fs.copyFileSync(path.join(onnx,'dist',runtime+'.mjs'),path.join(dist,'runtime',runtime+'.mjs'));
fs.writeFileSync(path.join(dist,'assets','ort-local.wasm.gz'),gzipSync(fs.readFileSync(path.join(onnx,'dist',runtime+'.wasm')),{level:9}));
for(const name of fs.readdirSync(path.join(dist,'assets')))if(name.endsWith('.wasm'))fs.unlinkSync(path.join(dist,'assets',name));
fs.writeFileSync(path.join(dist,'runtime','paths.json'),JSON.stringify({mjs:'./'+runtime+'.mjs',wasm:'../assets/ort-local.wasm.gz'}));
const files=[];function scan(dir){for(const name of fs.readdirSync(dir)){const full=path.join(dir,name);if(fs.statSync(full).isDirectory())scan(full);else if(!['sw.js','_headers'].includes(name))files.push('./'+path.relative(dist,full).split(path.sep).join('/'));}}scan(dist);
const revision='mega-mobile-'+Date.now();fs.writeFileSync(path.join(dist,'sw.js'),`
const CACHE=${JSON.stringify(revision)},FILES=${JSON.stringify(files)};
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('mega-mobile-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin)return;
 e.respondWith((async()=>{const cached=await caches.match(e.request);if(cached)return cached;try{return await fetch(e.request);}catch{return e.request.mode==='navigate'?(await caches.match('./index.html'))||Response.error():Response.error();}})());
});`);
fs.writeFileSync(path.join(dist,'_headers'),'/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: no-referrer\n  Permissions-Policy: geolocation=(), microphone=()\n  Content-Security-Policy: default-src \'self\'; script-src \'self\' \'wasm-unsafe-eval\'; worker-src \'self\' blob:; connect-src \'self\' https://huggingface.co https://*.hf.co https://*.xethub.hf.co https://raw.githubusercontent.com; img-src \'self\' data: blob:; style-src \'self\' \'unsafe-inline\'; object-src \'none\'; base-uri \'self\'; frame-ancestors \'none\'\n');
console.log('Offline-Shell:',files.length,'Dateien. Modelldateien werden nur nach Freigabe geladen.');
