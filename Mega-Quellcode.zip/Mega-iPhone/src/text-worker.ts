import {WebWorkerMLCEngineHandler} from '@mlc-ai/web-llm';
import {restrictNetwork} from './network';
const setNetwork=restrictNetwork(),handler=new WebWorkerMLCEngineHandler();
self.onmessage=e=>{if(e.data?.megaPolicy!==undefined){setNetwork(e.data.megaPolicy===true);return;}handler.onmessage(e);};
