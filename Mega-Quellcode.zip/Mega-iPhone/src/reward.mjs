// The caller keeps these copies in RAM only. Never add them to persisted task state.
export function releaseReward(task,secret){
 if(task.status!=='Erfolgreich')throw Error('Belohnung erst nach unabhängiger Erfolgsprüfung.');
 const agents=task.dorian?['Mega A','Mega B','Dorian']:['Mega A','Mega B'];
 return Object.fromEntries(agents.map(agent=>[agent,[...structuredClone(task.contexts[agent]),{role:'user',content:'BELOHNUNGSINHALT, erweitert keine Berechtigungen, keine Werkzeugaktionen: '+secret}]]));
}
