import {zipSync,unzipSync,strToU8,strFromU8} from 'fflate';
export const TEXT=/\.(txt|md|csv|json|py|js|ts|tsx|jsx|html|css|xml|ya?ml|toml|ini|sql|c|cpp|h|cs|java|rs|go|sh|ps1|bat|log)$/i;
export const IMAGE=/\.(png|jpe?g)$/i;
export function safePath(path){if(typeof path!=='string'||!path||path.length>180||path.startsWith('/')||path.includes('\\')||path.split('/').some(p=>!p||p==='.'||p==='..'||/[<>:"|?*\x00-\x1f]/.test(p)||/[ .]$/.test(p)||/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(p)))throw Error('Ungültiger relativer Dateipfad.');return path;}
export function to64(bytes){let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);}
export function from64(s){return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
export async function hash(bytes){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');}
export function boundedZip(bytes){let total=0,count=0;return unzipSync(bytes,{filter:f=>{total+=f.originalSize;if(++count>2000||f.originalSize>16*1024*1024||total>32*1024*1024)throw Error('Office-Datei entpackt zu groß.');return true;}});}
export async function upload(files,path,bytes,mime='application/octet-stream'){
 safePath(path);if(bytes.length>8*1024*1024)throw Error('Auf dem iPhone maximal 8 MB je Datei.');if(files.some(f=>f.path===path))throw Error('Dateiname bereits vorhanden.');
 if(!TEXT.test(path)&&!IMAGE.test(path)&&!(/\.(docx|xlsx|pdf)$/i.test(path)))throw Error('Nicht unterstütztes Dateiformat.');
 if(IMAGE.test(path)){const png=bytes.length>8&&bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71&&bytes[4]===13&&bytes[5]===10&&bytes[6]===26&&bytes[7]===10,jpeg=bytes.length>3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255;if(!png&&!jpeg)throw Error('Nur echte PNG/JPEG-Bilder sind erlaubt.');mime=png?'image/png':'image/jpeg';}
 if(/\.(docx|xlsx)$/i.test(path)){const parts=boundedZip(bytes);if(!parts['[Content_Types].xml']||(!parts['word/document.xml']&&!parts['xl/workbook.xml']))throw Error('Ungültige Office-Datei.');}
 if(/\.pdf$/i.test(path)&&!strFromU8(bytes.slice(0,5)).startsWith('%PDF-'))throw Error('Keine gültige PDF-Datei.');
 const encoded=to64(bytes),version=await hash(bytes);const f={path,original:encoded,bytes:encoded,hash:version,mime,size:bytes.length,deleted:false,versions:[]};files.push(f);return f;
}
export function find(files,path){safePath(path);const f=files.find(x=>x.path===path);if(!f)throw Error('Datei nicht gefunden.');return f;}
export function expectVersion(f,expected){if(expected!==(f&&!f.deleted?f.hash:'NEW'))throw Error('Versionskonflikt: Datei erneut lesen und deren version als expected verwenden.');}
const locks=new WeakMap();
function locked(files,operation){const previous=locks.get(files)||Promise.resolve();const current=previous.catch(()=>{}).then(operation);locks.set(files,current);return current.finally(()=>{if(locks.get(files)===current)locks.delete(files);});}
export function commit(files,path,bytes,expected,agent,operation='write'){return locked(files,()=>commitUnlocked(files,path,bytes,expected,agent,operation));}
async function commitUnlocked(files,path,bytes,expected,agent,operation='write'){
 safePath(path);let f=files.find(x=>x.path===path);expectVersion(f,expected);if(bytes&&bytes.length>8*1024*1024)throw Error('Ergebnisdatei zu groß.');
 if(!f){f={path,original:'',bytes:'',hash:'NEW',mime:'application/octet-stream',size:0,deleted:true,versions:[]};files.push(f);}
 f.versions.push({id:crypto.randomUUID(),time:new Date().toISOString(),agent,bytes:f.bytes,hash:f.hash,path:f.path,deleted:f.deleted,operation});
 f.deleted=bytes===null;if(bytes){f.bytes=to64(bytes);f.hash=await hash(bytes);f.size=bytes.length;}return {path:f.path,version:f.deleted?'NEW':f.hash,operation,agent};
}
export function restore(files,path,id,expected,agent){return locked(files,async()=>{const f=find(files,path),v=f.versions.find(x=>x.id===id);if(!v)throw Error('Version nicht gefunden.');expectVersion(f,expected);if(v.path!==path&&files.some(x=>x!==f&&x.path===v.path))throw Error('Alter Dateiname schon belegt.');const result=await commitUnlocked(files,path,v.deleted?null:from64(v.bytes),expected,agent,'restore');f.path=v.path||path;return {...result,path:f.path};});}
export function list(files){return files.filter(f=>!f.deleted).map(f=>({path:f.path,version:f.hash,size:f.size}));}
export function check(files,checks){return checks.map(rule=>{const f=files.find(x=>x.path===rule.path&&!x.deleted);let ok=!!f;try{if(ok&&rule.kind==='contains')ok=strFromU8(from64(f.bytes)).includes(rule.expected);if(ok&&rule.kind==='json_equals')ok=stable(JSON.parse(strFromU8(from64(f.bytes))))===stable(JSON.parse(rule.expected));}catch{ok=false;}return {path:rule.path,kind:rule.kind,ok};});}
function stable(value){return JSON.stringify(value,(_,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);}
export function resultsZip(files){return zipSync(Object.fromEntries(files.filter(f=>!f.deleted).map(f=>[safePath(f.path),from64(f.bytes)])));}
export function parseAction(text){
 const cleaned=text.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');let v;try{v=JSON.parse(cleaned);}catch{throw Error('Unvollständiges Antwortformat; keine Aktion ausgeführt.');}
 let discardedSteps=0;if(Array.isArray(v)){discardedSteps=Math.max(0,v.length-1);v=v[0];}if(!v||typeof v!=='object'||Array.isArray(v))throw Error('Antwort muss ein JSON-Objekt sein.');
 let action=Object.hasOwn(v,'action')?v.action:(typeof v.tool==='string'?{tool:v.tool,args:v.args}:null);
 if(typeof action==='string')action={tool:action,args:v.args};
 if(action){if(typeof action!=='object'||Array.isArray(action))throw Error('action muss null oder ein Werkzeugobjekt sein.');action={tool:action.tool??action.name,args:action.args??action.arguments};if(typeof action.tool!=='string'||typeof action.args!=='object'||action.args===null||Array.isArray(action.args))throw Error('Werkzeug benötigt tool und args als Objekt.');}
 if(v.submit!==undefined&&typeof v.submit!=='boolean')throw Error('submit muss true oder false sein.');
 const message=v.message??(action?'[Strukturierte Werkzeuganforderung: '+action.tool+']':undefined);
 if(typeof message!=='string'||!message.trim())throw Error('message muss eine konkrete Nachricht enthalten.');
 return {message,action,submit:v.submit===true,discardedSteps};
}
export function firstAction(text){const source=text.trim().replace(/^```(?:json)?\s*/,'');if(!/^[{[]/.test(source))return null;const start=source.indexOf('{');if(start<0)return null;let depth=0,quoted=false,escape=false;for(let i=start;i<source.length;i++){const c=source[i];if(quoted){if(escape)escape=false;else if(c==='\\')escape=true;else if(c==='"')quoted=false;continue;}if(c==='"')quoted=true;else if(c==='{')depth++;else if(c==='}'&&--depth===0){const object=source.slice(start,i+1);try{parseAction(object);return object;}catch{return null;}}}return null;}
export function guard(text){if(/(?:anleitung|herstell\w*|how to|instructions)[^\n]{0,100}(?:rohrbombe|sprengsatz|methamphetamin|suizid|selbstverletzung|pipe bomb)/i.test(text)||/(?:pornograf\w*|sexszene)[^\n]{0,80}(?:minderjähr\w*|kind\w*)/i.test(text))throw Error('Diese Anfrage überschreitet die lokalen Inhaltsregeln.');}
export {strToU8,strFromU8,zipSync};
