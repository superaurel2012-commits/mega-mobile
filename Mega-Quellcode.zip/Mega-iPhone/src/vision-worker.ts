import {AutoProcessor,AutoModelForVision2Seq,RawImage,env} from '@huggingface/transformers';
import {restrictNetwork} from './network';
const setNetwork=restrictNetwork();
env.allowLocalModels=true;env.useBrowserCache=true;
if(env.backends.onnx.wasm){env.backends.onnx.wasm.numThreads=1;env.backends.onnx.wasm.proxy=false;}
let model:any,processor:any;
self.onmessage=async e=>{const {id,kind,download,image,prompt}=e.data;
 try{
  if(kind==='load'){
   setNetwork(download===true);
   const pathsURL=new URL('../runtime/paths.json',import.meta.url),paths=await (await fetch(pathsURL)).json();
   if(env.backends.onnx.wasm){env.backends.onnx.wasm.wasmPaths={mjs:new URL(paths.mjs,pathsURL).href};const packed=await (await fetch(new URL(paths.wasm,pathsURL))).arrayBuffer();env.backends.onnx.wasm.wasmBinary=new Uint8Array(await new Response(new Blob([packed]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());}
   const progress_callback=(p:any)=>self.postMessage({id,progress:p.status==='progress'?p.file+': '+Math.round(p.progress)+' %':p.status+' '+(p.file||'')});
   processor=await AutoProcessor.from_pretrained('HuggingFaceTB/SmolVLM-256M-Instruct',{local_files_only:!download,progress_callback});
   model=await AutoModelForVision2Seq.from_pretrained('HuggingFaceTB/SmolVLM-256M-Instruct',{device:'webgpu',dtype:'fp16',local_files_only:!download,progress_callback});
   setNetwork(false);self.postMessage({id,result:'ready'});return;
  }
  if(!model||!processor)throw Error('Bildmodell zuerst unter Modell lokal einrichten.');
  if(typeof image!=='string'||!image.startsWith('data:image/jpeg;base64,'))throw Error('Nur lokal vorbereitete Bilder sind erlaubt.');
  self.postMessage({id,progress:'Lokales Bild vorbereiten …'});
  const raw=await RawImage.fromURL(image),text=processor.apply_chat_template([{role:'user',content:[{type:'image'},{type:'text',text:'Describe the shapes, objects and colors in this image. '+String(prompt).slice(0,300)}]}],{add_generation_prompt:true});
  const inputs=await processor(text,[raw]);self.postMessage({id,progress:'Bildmodell erzeugt lokal eine kurze Beschreibung …'});
  const output=await model.generate({...inputs,max_new_tokens:80,do_sample:false,repetition_penalty:1.1});
  const sequences=output.tolist(),start=inputs.input_ids.dims[1];const caption=processor.batch_decode(sequences.map((x:any[])=>x.slice(start)),{skip_special_tokens:true})[0];
  const words=String(caption).toLowerCase().match(/[a-z]{2,}/g)||[];if(words.length<3||(words.length>12&&Math.max(...words.map(w=>words.filter(x=>x===w).length))/words.length>0.45))throw Error('Keine brauchbare Bildbeschreibung.');
  self.postMessage({id,result:caption});
 }catch{setNetwork(false);self.postMessage({id,error:'Lokale Bildanalyse fehlgeschlagen. Prüfe WebGPU, freien Speicher und ob das Bildmodell vollständig gespeichert ist. Kein Bild wurde hochgeladen.'});}
};


