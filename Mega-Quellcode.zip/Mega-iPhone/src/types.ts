export type Agent='Mega A'|'Mega B'|'Dorian';
export type Message={id:string;sender:Agent|'Du'|'Steuerung';recipient:string;time:string;type:string;text:string;receipts:Agent[];image?:string};
export type Context={role:'user'|'assistant';content:string};
export type Revision={id:string;time:string;agent:string;bytes:string;hash:string;operation:string};
export type WorkFile={path:string;original:string;bytes:string;hash:string;mime:string;size:number;deleted:boolean;versions:Revision[]};
export type Session={id:string;agent:'Mega A'|'Mega B';title:string;messages:Message[];context:Context[]};
export type Check={kind:'exists'|'contains'|'json_equals';path:string;expected?:string};
export type TeamTask={id:string;goal:string;criteria:string;dorian:boolean;status:string;messages:Message[];contexts:Record<Agent,Context[]>;files:WorkFile[];submitted:Agent[];checks:Check[];verification:'manual'|'tests';turn:number};
export type AppState={version:3;sessions:Session[];tasks:TeamTask[];selectedSession:string;selectedTask:string};
export type ToolAction={tool:string;args:Record<string,any>};
export const uid=()=>crypto.randomUUID();
export const stamp=()=>new Date().toISOString();
export function message(sender:Message['sender'],recipient:string,type:string,text:string,image?:string):Message{return {id:uid(),sender,recipient,type,text,time:stamp(),receipts:[],...(image?{image}:{})};}
export const newSession=(agent:'Mega A'|'Mega B'):Session=>({id:uid(),agent,title:'Neuer Chat',messages:[],context:[]});
export const initial=():AppState=>{const a=newSession('Mega A'),b=newSession('Mega B');return {version:3,sessions:[a,b],tasks:[],selectedSession:a.id,selectedTask:''};};
